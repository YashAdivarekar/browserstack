// import logo from './logo.svg';
// import './App.css';
// import React, { useState } from 'react';

// function App() {
//   const [inputText, setInputText] = useState('');

//   const handleInputChange = (event) => {
//     setInputText(event.target.value);
//   };

//   return (
//     <div>
//       <center><textarea value={inputText} onChange={handleInputChange} /></center>
//       <center><pre>{inputText}</pre></center>
//     </div>
//   );
// }


// export default App;

import { useEffect,useState } from "react";
import io from "socket.io-client"

const socket = io('http://localhost:5000');

function App() {
const [notification,setNotification]=useState([]);

  useEffect(() => {
    socket.on('message', ({ message }) => {
      setNotification((prev)=>[...prev,message]);
    });

    return () => {
      socket.off('message');
    };
  },[])

  return(
    <div>
      <h1>Push Notifications</h1>
      <ul>
        {notification.map((notifi, index) => (
          <li key={index}>{notifi.message}</li>
        ))}
      </ul>
    </div>
  )

}

export default App;
